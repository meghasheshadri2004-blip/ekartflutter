import 'package:flutter/material.dart';
import '../../services/services.dart';
import '../../services/auth_service.dart';
import '../login_screen.dart';
import 'admin_coupon_screen.dart';
import 'admin_refund_screen.dart';
import 'admin_delivery_screen.dart';
import 'admin_stats_screen.dart';
import 'admin_accounts_screen.dart';
import 'admin_reviews_screen.dart';
import 'admin_banners_screen.dart';
import 'admin_warehouses_screen.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});
  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  int _tab = 0;
  List<Map<String, dynamic>> products  = [];
  List<Map<String, dynamic>> customers = [];
  List<Map<String, dynamic>> vendors   = [];
  List<Map<String, dynamic>> orders    = [];
  bool loading = true;

  static const List<String> _statuses = [
    'PROCESSING', 'PACKED', 'SHIPPED', 'OUT_FOR_DELIVERY', 'DELIVERED', 'CANCELLED'
  ];

  static const _tabs = [
    ('Dashboard',  Icons.dashboard_outlined),
    ('Products',   Icons.inventory_2_outlined),
    ('Customers',  Icons.people_outline),
    ('Vendors',    Icons.store_outlined),
    ('Orders',     Icons.receipt_long_outlined),
    ('Coupons',    Icons.discount_outlined),
    ('Refunds',    Icons.assignment_return_outlined),
    ('Delivery',   Icons.delivery_dining_outlined),
    ('Warehouses', Icons.warehouse_outlined),
    ('Banners',    Icons.image_outlined),
    ('Reviews',    Icons.star_outline),
    ('Accounts',   Icons.manage_accounts_outlined),
  ];

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => loading = true);
    final results = await Future.wait([
      AdminService.getProducts(),
      AdminService.getUsers(),
      AdminService.getOrders(),
    ]);
    if (!mounted) return;
    final prodRes  = results[0];
    final usersRes = results[1];
    final ordRes   = results[2];
    setState(() {
      products  = prodRes['success']  == true ? List<Map<String, dynamic>>.from(prodRes['products']   ?? []) : [];
      customers = usersRes['success'] == true ? List<Map<String, dynamic>>.from(usersRes['customers'] ?? []) : [];
      vendors   = usersRes['success'] == true ? List<Map<String, dynamic>>.from(usersRes['vendors']   ?? []) : [];
      orders    = ordRes['success']   == true ? List<Map<String, dynamic>>.from(ordRes['orders']      ?? []) : [];
      loading   = false;
    });
  }

  void _snack(String msg, Color color) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg), backgroundColor: color, behavior: SnackBarBehavior.floating));

  @override
  Widget build(BuildContext context) {
    final pending = products.where((p) => p['approved'] == false).length;
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          const Icon(Icons.admin_panel_settings, color: Colors.white),
          const SizedBox(width: 8),
          const Text('Admin Dashboard', style: TextStyle(fontWeight: FontWeight.bold)),
          if (pending > 0) ...[
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.all(5),
              decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
              child: Text('$pending',
                  style: TextStyle(color: Colors.red.shade700, fontSize: 10, fontWeight: FontWeight.bold)),
            ),
          ],
        ]),
        backgroundColor: Colors.red.shade700,
        foregroundColor: Colors.white,
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              AuthService.logout();
              Navigator.pushAndRemoveUntil(context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
            },
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Column(children: [
              // Scrollable tab bar
              Container(
                color: Colors.red.shade700,
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: _tabs.asMap().entries.map((e) {
                      final selected = _tab == e.key;
                      return GestureDetector(
                        onTap: () => setState(() => _tab = e.key),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                          decoration: BoxDecoration(
                            border: Border(bottom: BorderSide(
                                color: selected ? Colors.white : Colors.transparent, width: 3)),
                          ),
                          child: Row(mainAxisSize: MainAxisSize.min, children: [
                            Icon(e.value.$2,
                                color: selected ? Colors.white : Colors.white54, size: 16),
                            const SizedBox(width: 5),
                            Text(e.value.$1,
                                style: TextStyle(
                                    color: selected ? Colors.white : Colors.white60,
                                    fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                                    fontSize: 13)),
                          ]),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
              // Content
              Expanded(
                child: RefreshIndicator(
                  onRefresh: _load,
                  child: IndexedStack(
                    index: _tab,
                    children: [
                      const AdminStatsScreen(),       // 0
                      _buildProducts(),               // 1
                      _buildCustomers(),              // 2
                      _buildVendors(),                // 3
                      _buildOrders(),                 // 4
                      const AdminCouponScreen(),      // 5
                      const AdminRefundScreen(),      // 6
                      const AdminDeliveryScreen(),    // 7
                      const AdminWarehousesScreen(),  // 8
                      const AdminBannersScreen(),     // 9
                      const AdminReviewsScreen(),     // 10
                      const AdminAccountsScreen(),    // 11
                    ],
                  ),
                ),
              ),
            ]),
    );
  }

  // ── PRODUCTS ──────────────────────────────────────────────────────────────
  Widget _buildProducts() {
    if (products.isEmpty) return const Center(child: Text('No products found'));
    final pending  = products.where((p) => p['approved'] == false).toList();
    final approved = products.where((p) => p['approved'] == true).toList();
    return ListView(padding: const EdgeInsets.all(12), children: [
      if (pending.isNotEmpty) ...[
        Row(children: [
          Text('Pending Approval (${pending.length})',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const Spacer(),
          TextButton.icon(
            icon: const Icon(Icons.done_all, size: 16),
            label: const Text('Approve All'),
            onPressed: () async {
              final res = await AdminService.approveAllProducts();
              _snack(res['message'] ?? 'Done', res['success'] == true ? Colors.green : Colors.red);
              _load();
            },
          ),
        ]),
        ...pending.map((p) => _productCard(p, isPending: true)),
        const Divider(height: 24),
      ],
      if (approved.isNotEmpty) ...[
        Text('Approved (${approved.length})',
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        const SizedBox(height: 8),
        ...approved.map((p) => _productCard(p, isPending: false)),
      ],
    ]);
  }

  Widget _productCard(Map<String, dynamic> p, {required bool isPending}) {
    final id    = p['id']    as int?    ?? 0;
    final name  = p['name']  as String? ?? '';
    final price = (p['price'] as num?   ?? 0).toDouble();
    final stock = p['stock'] as int?    ?? 0;
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      color: isPending ? Colors.orange.shade50 : null,
      child: ListTile(
        leading: ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: Image.network(p['imageLink'] as String? ?? '',
              width: 48, height: 48, fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                  width: 48, height: 48, color: Colors.grey[200],
                  child: const Icon(Icons.image_not_supported, size: 20))),
        ),
        title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text('₹${price.toStringAsFixed(0)} • Stock: $stock'),
        trailing: isPending
            ? Row(mainAxisSize: MainAxisSize.min, children: [
                IconButton(icon: const Icon(Icons.close, color: Colors.red), tooltip: 'Reject',
                    onPressed: () async {
                      final res = await AdminService.rejectProduct(id);
                      _snack(res['message'] ?? 'Rejected', res['success'] == true ? Colors.green : Colors.red);
                      _load();
                    }),
                IconButton(icon: const Icon(Icons.check, color: Colors.green), tooltip: 'Approve',
                    onPressed: () async {
                      final res = await AdminService.approveProduct(id);
                      _snack(res['message'] ?? 'Approved', res['success'] == true ? Colors.green : Colors.red);
                      _load();
                    }),
              ])
            : Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(color: Colors.green.shade100, borderRadius: BorderRadius.circular(12)),
                child: const Text('Approved', style: TextStyle(color: Colors.green, fontSize: 11))),
      ),
    );
  }

  // ── CUSTOMERS ─────────────────────────────────────────────────────────────
  Widget _buildCustomers() {
    if (customers.isEmpty) return const Center(child: Text('No customers found'));
    return ListView.builder(
      padding: const EdgeInsets.all(12), itemCount: customers.length,
      itemBuilder: (ctx, i) {
        final c = customers[i];
        final id = c['id'] as int? ?? 0;
        final name = c['name'] as String? ?? '';
        final email = c['email'] as String? ?? '';
        final active = c['active'] as bool? ?? true;
        return Card(margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: active ? Colors.blue.shade100 : Colors.grey.shade200,
              child: Text(name.isNotEmpty ? name[0].toUpperCase() : 'C',
                  style: TextStyle(color: active ? Colors.blue.shade800 : Colors.grey, fontWeight: FontWeight.bold)),
            ),
            title: Text(name, style: const TextStyle(fontWeight: FontWeight.w600)),
            subtitle: Text(email, style: const TextStyle(fontSize: 12)),
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                    color: active ? Colors.green.shade100 : Colors.red.shade100,
                    borderRadius: BorderRadius.circular(12)),
                child: Text(active ? 'Active' : 'Banned',
                    style: TextStyle(color: active ? Colors.green : Colors.red, fontSize: 11))),
              IconButton(
                icon: Icon(active ? Icons.block : Icons.check_circle_outline,
                    color: active ? Colors.red : Colors.green, size: 20),
                tooltip: active ? 'Ban' : 'Unban',
                onPressed: () async {
                  final res = await AdminService.toggleCustomer(id);
                  _snack(res['message'] ?? 'Done', res['success'] == true ? Colors.green : Colors.red);
                  _load();
                }),
            ]),
          ));
      },
    );
  }

  // ── VENDORS ───────────────────────────────────────────────────────────────
  Widget _buildVendors() {
    if (vendors.isEmpty) return const Center(child: Text('No vendors found'));
    return ListView.builder(
      padding: const EdgeInsets.all(12), itemCount: vendors.length,
      itemBuilder: (ctx, i) {
        final v = vendors[i];
        final id = v['id'] as int? ?? 0;
        final name = v['name'] as String? ?? '';
        final email = v['email'] as String? ?? '';
        final active = v['active'] as bool? ?? true;
        final code = v['vendorCode'] as String? ?? '';
        return Card(margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: active ? Colors.indigo.shade100 : Colors.grey.shade200,
              child: Text(name.isNotEmpty ? name[0].toUpperCase() : 'V',
                  style: TextStyle(color: active ? Colors.indigo.shade800 : Colors.grey, fontWeight: FontWeight.bold)),
            ),
            title: Text(name, style: const TextStyle(fontWeight: FontWeight.w600)),
            subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(email, style: const TextStyle(fontSize: 12)),
              if (code.isNotEmpty) Text(code, style: TextStyle(fontSize: 11, color: Colors.grey[500])),
            ]),
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                    color: active ? Colors.green.shade100 : Colors.red.shade100,
                    borderRadius: BorderRadius.circular(12)),
                child: Text(active ? 'Active' : 'Banned',
                    style: TextStyle(color: active ? Colors.green : Colors.red, fontSize: 11))),
              IconButton(
                icon: Icon(active ? Icons.block : Icons.check_circle_outline,
                    color: active ? Colors.red : Colors.green, size: 20),
                tooltip: active ? 'Suspend' : 'Reinstate',
                onPressed: () async {
                  final res = await AdminService.toggleVendor(id);
                  _snack(res['message'] ?? 'Done', res['success'] == true ? Colors.green : Colors.red);
                  _load();
                }),
            ]),
          ));
      },
    );
  }

  // ── ORDERS ────────────────────────────────────────────────────────────────
  Widget _buildOrders() {
    if (orders.isEmpty) return const Center(child: Text('No orders found'));
    return ListView.builder(
      padding: const EdgeInsets.all(12), itemCount: orders.length,
      itemBuilder: (ctx, i) {
        final o = orders[i];
        final id     = o['id'] as int? ?? 0;
        final total  = (o['totalPrice'] as num? ?? 0).toDouble();
        final status = o['trackingStatus'] as String? ?? 'PROCESSING';
        final name   = o['customerName'] as String? ?? 'Customer';
        return Card(
          margin: const EdgeInsets.only(bottom: 10),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Text('Order #$id', style: const TextStyle(fontWeight: FontWeight.bold)),
                const Spacer(),
                Text('₹${total.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)),
              ]),
              const SizedBox(height: 4),
              Row(children: [
                const Icon(Icons.person_outline, size: 14, color: Colors.grey),
                const SizedBox(width: 4),
                Text(name, style: const TextStyle(fontSize: 12)),
              ]),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                initialValue: _statuses.contains(status) ? status : _statuses.first,
                decoration: InputDecoration(
                  labelText: 'Status', isDense: true,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                ),
                items: _statuses.map((s) => DropdownMenuItem(
                    value: s, child: Text(s.replaceAll('_', ' '), style: const TextStyle(fontSize: 13)))).toList(),
                onChanged: (newStatus) async {
                  if (newStatus == null) return;
                  final res = await AdminService.updateOrderStatus(id, newStatus);
                  _snack(res['message'] ?? 'Updated', res['success'] == true ? Colors.green : Colors.red);
                  _load();
                },
              ),
            ]),
          ),
        );
      },
    );
  }
}