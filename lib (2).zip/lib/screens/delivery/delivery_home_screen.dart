import 'package:flutter/material.dart';
import '../../services/services.dart';
import '../../services/auth_service.dart';
import '../login_screen.dart';
import 'delivery_order_card.dart';
import 'delivery_warehouse_screen.dart';

class DeliveryHomeScreen extends StatefulWidget {
  const DeliveryHomeScreen({super.key});
  @override
  State<DeliveryHomeScreen> createState() => _DeliveryHomeScreenState();
}

class _DeliveryHomeScreenState extends State<DeliveryHomeScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _loading = true;

  List<Map<String, dynamic>> _toPickUp  = [];
  List<Map<String, dynamic>> _outNow    = [];
  List<Map<String, dynamic>> _delivered = [];
  Map<String, dynamic>? _profile;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _load();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final res = await DeliveryBoyService.getHome();
      if (!mounted) return;
      if (res['success'] == true) {
        setState(() {
          _profile  = res['profile'] as Map<String, dynamic>?;
          _toPickUp = List<Map<String, dynamic>>.from(res['toPickUp']  ?? []);
          _outNow   = List<Map<String, dynamic>>.from(res['outNow']    ?? []);
          _delivered= List<Map<String, dynamic>>.from(res['delivered'] ?? []);
          _loading  = false;
        });
      } else {
        setState(() => _loading = false);
        _snack(res['message'] ?? 'Failed to load', Colors.red);
      }
    } catch (e) {
      setState(() => _loading = false);
      _snack('Error: $e', Colors.red);
    }
  }

  void _snack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(msg),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating));
  }

  Future<void> _markPickedUp(Map<String, dynamic> order) async {
    final res = await DeliveryBoyService.markPickedUp(order['id']);
    _snack(
      res['message'] ?? (res['success'] == true ? 'Marked as Out for Delivery' : 'Failed'),
      res['success'] == true ? Colors.green : Colors.red,
    );
    if (res['success'] == true) _load();
  }

  Future<void> _confirmDelivery(Map<String, dynamic> order) async {
    final otpCtrl = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(children: [
          Icon(Icons.verified_outlined, color: Colors.teal),
          SizedBox(width: 8),
          Text('Confirm Delivery'),
        ]),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('Order #${order['id']}',
              style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text('Customer: ${(order['customer'] as Map?)?['name'] ?? ''}',
              style: TextStyle(color: Colors.grey[600], fontSize: 13)),
          const SizedBox(height: 14),
          const Text('Enter the OTP shown in the customer\'s app:',
              style: TextStyle(fontSize: 13)),
          const SizedBox(height: 10),
          TextField(
            controller: otpCtrl,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'Delivery OTP',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.lock_open_outlined),
            ),
            maxLength: 6,
          ),
        ]),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
            icon: const Icon(Icons.check, color: Colors.white, size: 18),
            label: const Text('Confirm', style: TextStyle(color: Colors.white)),
            onPressed: () => Navigator.pop(context, true),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    final otp = int.tryParse(otpCtrl.text.trim()) ?? 0;
    final res = await DeliveryBoyService.confirmDelivery(order['id'], otp);
    _snack(
      res['message'] ?? (res['success'] == true ? 'Delivered!' : 'Failed'),
      res['success'] == true ? Colors.green : Colors.red,
    );
    if (res['success'] == true) _load();
  }

  @override
  Widget build(BuildContext context) {
    final user         = AuthService.currentUser;
    final code         = user?.deliveryBoyCode ?? '';
    final warehouse    = _profile?['warehouse'] as Map<String, dynamic>?;
    final pins         = _profile?['assignedPinCodes'] as String? ?? '';
    final hasPending   = _profile?['hasPendingWarehouseRequest'] == true;

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Delivery Dashboard',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          if (code.isNotEmpty)
            Text(code, style: const TextStyle(fontSize: 11, color: Colors.white70)),
        ]),
        backgroundColor: Colors.teal.shade700,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.warehouse_outlined),
            tooltip: 'Warehouse Transfer',
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const DeliveryWarehouseScreen())),
          ),
          IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              AuthService.logout();
              Navigator.pushAndRemoveUntil(context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                  (_) => false);
            },
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          tabs: [
            Tab(text: 'To Pick Up (${_toPickUp.length})'),
            Tab(text: 'Out for Del. (${_outNow.length})'),
            Tab(text: 'Delivered (${_delivered.length})'),
          ],
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(children: [
              _buildProfileCard(user?.name ?? '', warehouse, pins, hasPending),
              _buildStatsRow(),
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    _buildOrderList(_toPickUp,
                        emptyMsg: 'No orders to pick up',
                        emptyIcon: Icons.inbox_outlined,
                        actionLabel: '🛵  Mark Picked Up',
                        actionColor: Colors.orange.shade700,
                        onAction: _markPickedUp),
                    _buildOrderList(_outNow,
                        emptyMsg: 'No orders out for delivery',
                        emptyIcon: Icons.local_shipping_outlined,
                        actionLabel: '✅  Confirm Delivery (OTP)',
                        actionColor: Colors.green.shade700,
                        onAction: _confirmDelivery),
                    _buildOrderList(_delivered,
                        emptyMsg: 'No deliveries yet',
                        emptyIcon: Icons.check_circle_outline),
                  ],
                ),
              ),
            ]),
    );
  }

  Widget _buildProfileCard(String name, Map<String, dynamic>? warehouse,
      String pins, bool hasPending) {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 12, 12, 6),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
            colors: [Colors.teal.shade700, Colors.teal.shade500]),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
              color: Colors.teal.withValues(alpha: 0.25),
              blurRadius: 10,
              offset: const Offset(0, 4))
        ],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          CircleAvatar(
            backgroundColor: Colors.white24,
            radius: 22,
            child: Text(
              name.isNotEmpty ? name[0].toUpperCase() : 'D',
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name,
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
              if (warehouse != null)
                Text('📦 ${warehouse['name']} · ${warehouse['city']}',
                    style: const TextStyle(color: Colors.white70, fontSize: 12)),
              if (pins.isNotEmpty)
                Text('Pincodes: $pins',
                    style: const TextStyle(color: Colors.white60, fontSize: 11)),
            ]),
          ),
        ]),
        if (hasPending) ...[
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
                color: Colors.amber.withValues(alpha: 0.25),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.amber.withValues(alpha: 0.5))),
            child: const Row(children: [
              Icon(Icons.hourglass_top_rounded, color: Colors.amber, size: 14),
              SizedBox(width: 6),
              Expanded(
                child: Text('Warehouse change request pending admin review',
                    style: TextStyle(color: Colors.amber, fontSize: 11)),
              ),
            ]),
          ),
        ],
      ]),
    );
  }

  Widget _buildStatsRow() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
      child: Row(children: [
        _statCard('${_toPickUp.length}', 'To Pick Up', Colors.orange),
        const SizedBox(width: 8),
        _statCard('${_outNow.length}', 'Out for Del.', Colors.blue),
        const SizedBox(width: 8),
        _statCard('${_delivered.length}', 'Delivered', Colors.green),
      ]),
    );
  }

  Widget _statCard(String value, String label, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
            color: color.withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: color.withValues(alpha: 0.2))),
        child: Column(children: [
          Text(value,
              style: TextStyle(
                  fontWeight: FontWeight.bold, fontSize: 20, color: color)),
          Text(label,
              style: TextStyle(fontSize: 10, color: Colors.grey[600]),
              textAlign: TextAlign.center),
        ]),
      ),
    );
  }

  Widget _buildOrderList(
    List<Map<String, dynamic>> orders, {
    required String emptyMsg,
    required IconData emptyIcon,
    String? actionLabel,
    Color? actionColor,
    Future<void> Function(Map<String, dynamic>)? onAction,
  }) {
    if (orders.isEmpty) {
      return Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(emptyIcon, size: 56, color: Colors.grey[300]),
          const SizedBox(height: 12),
          Text(emptyMsg,
              style: TextStyle(color: Colors.grey[500], fontSize: 15)),
        ]),
      );
    }
    return RefreshIndicator(
      onRefresh: () => _load(),
      child: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: orders.length,
        itemBuilder: (ctx, i) => DeliveryOrderCard(
          order: orders[i],
          actionLabel: actionLabel,
          actionColor: actionColor,
          onAction: onAction != null ? () => onAction(orders[i]) : null,
        ),
      ),
    );
  }
}